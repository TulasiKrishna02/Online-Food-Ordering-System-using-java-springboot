package com.tulasi.bank_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
