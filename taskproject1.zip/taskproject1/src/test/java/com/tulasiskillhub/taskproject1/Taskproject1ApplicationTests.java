package com.tulasiskillhub.taskproject1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Taskproject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
